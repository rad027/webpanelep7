<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Socialite and Social Media Language Lines
    |--------------------------------------------------------------------------
    |
    */

    'denied'          => 'Vous n\'avez pas partagé les données du réseau social avec notre site Internet.',
    'noProvider'      => 'Aucun fournisseur social connu.',
    'registerSuccess' => 'Vous êtes bien enregistré, merci.',

];
