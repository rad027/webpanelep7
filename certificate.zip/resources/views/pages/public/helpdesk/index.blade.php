@extends('adminlte::page')

@section('title', 'Helpdesk')

@section('content_header')
    <h1>Helpdesk</h1>
@stop

@section('content')
<div class="row">
    <div class="col-md-3" style="padding: 0px 5px 0px 5px">
        @include('partials.sidepanel')
    </div>
    <div class="col-md-9" style="padding: 0px 5px 0px 5px">
    	<div class="box">
    		<div class="box-body">
				
    		</div>
    	</div>
	</div>
</div>
@stop

@section('css')

@stop

@section('js')

@stop